package live.hongcai.personalwebsite.dao;

import live.hongcai.personalwebsite.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Repository
public class ArticleRepository {

    private final JdbcTemplate jdbcTemplate;

    private final StringBuilder selectArticle =
            new StringBuilder()
                    .append("SELECT ID, TITLE, IMAGE_TITLE_URL, TYPE, CONTENT, TO_CHAR(TIME,'YYYY-MM-DD HH24:MI:SS') TIME")
                    .append(" FROM ARTICLE");

    @Autowired
    public ArticleRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Article mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        return new Article(
                resultSet.getInt("id"),
                resultSet.getString("title"),
                resultSet.getString("image_title_url"),
                resultSet.getInt("type"),
                resultSet.getString("content"),
                resultSet.getString("time")
        );
    }

    public int postArticle(Article article) {
        return jdbcTemplate.update(
                new StringBuilder()
                        .append("INSERT INTO ARTICLE VALUES")
                        .append("(HCL_ARTICLE_S.nextval, ?, ?, ?, ?, SYSDATE)")
                        .toString(),
                article.getTitle(),
                article.getImage_title_url(),
                article.getType(),
                article.getContent()
        );
    }

    public List<Article> getArticle(Integer id) {
        return jdbcTemplate.query(
                new StringBuilder()
                        .append(selectArticle)
                        .append(" WHERE ID = ?")
                        .toString(),
                this::mapRow,
                id
        );
    }

    public List<Article> getArticles(Integer type, Integer size) {
        return jdbcTemplate.query(
                new StringBuilder()
                        .append(selectArticle)
                        .append(" WHERE type = ?")
                        .append(" AND ROWNUM <= ?")
                        .toString(),
                this::mapRow,
                type,
                size
        );
    }
}

package live.hongcai.personalwebsite.model;

import java.util.Date;

public class Article {
    private final Integer id;
    private final String title;
    private String image_title_url;
    private final Integer type;
    private final String content;
    private final String time;

    public Article(Integer id, String title, String image_title_url, Integer type, String content, String time) {
        this.id = id;
        this.title = title;
        this.image_title_url = image_title_url;
        this.type = type;
        this.content = content;
        this.time = time;
    }

    public Integer getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getImage_title_url() {
        return image_title_url;
    }

    public Integer getType() {
        return type;
    }

    public String getContent() {
        return content;
    }

    public String getTime() {
        return time;
    }

    public void setImage_title_url(String image_title_url) {
        this.image_title_url = image_title_url;
    }
}

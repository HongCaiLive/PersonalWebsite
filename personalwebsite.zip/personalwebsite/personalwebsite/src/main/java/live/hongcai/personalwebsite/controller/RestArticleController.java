package live.hongcai.personalwebsite.controller;

import live.hongcai.personalwebsite.dao.ArticleRepository;
import live.hongcai.personalwebsite.dao.FileRepository;
import live.hongcai.personalwebsite.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/article")
public class RestArticleController {

    private ArticleRepository articleRepository;
    private FileRepository fileRepository;

    @Autowired
    public RestArticleController(ArticleRepository articleRepository, FileRepository fileRepository) {
        this.articleRepository = articleRepository;
        this.fileRepository = fileRepository;
    }

    @PostMapping
    public int postArticle(
            @RequestPart("imagetitle") MultipartFile imagetitle,
            Article article) {
        article.setImage_title_url(
                fileRepository.storeFile(imagetitle)
        );
        return articleRepository.postArticle(article);
    }

    @GetMapping("/{id}")
    public List<Article> getArticle(@PathVariable Integer id) {
        if(id == null) {
            return null;
        }
        return articleRepository.getArticle(id);
    }


}

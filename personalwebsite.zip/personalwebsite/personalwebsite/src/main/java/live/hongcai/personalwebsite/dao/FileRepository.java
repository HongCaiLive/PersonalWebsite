package live.hongcai.personalwebsite.dao;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

@Component
public class FileRepository {

    private static final SimpleDateFormat  dateFormat = new SimpleDateFormat("yyyyMMdd");

    public String storeFile(MultipartFile multipartFile) {
        if (multipartFile.isEmpty()) {
            return "file empty";
        }
        String originalFilename = multipartFile.getOriginalFilename();
        StringBuilder absolutePath = new StringBuilder()
                .append(System.getProperty("catalina.home"))
                .append("/work/Tomcat/localhost/");
        StringBuilder fileName =
                new StringBuilder()
                        .append("upload/")
                        .append(dateFormat.format(new Date()))
                        .append("/")
                        .append(getRandomString())
                        .append(originalFilename.substring(originalFilename.lastIndexOf('.')));
        File file = new File(absolutePath.append(fileName).toString());
        if (!file.getParentFile().exists()) {
            file.getParentFile().mkdirs();
        }
        try {
            multipartFile.transferTo(file);
            return fileName.toString();
        } catch (Exception e) {
            return e.getMessage();
        }
    }

    public String getRandomString() {
        int length = 10;
        String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(62);
            stringBuffer.append(str.charAt(number));
        }
        return stringBuffer.toString();
    }
}

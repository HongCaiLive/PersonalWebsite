package live.hongcai.personalwebsite.controller;

import live.hongcai.personalwebsite.dao.ArticleRepository;
import live.hongcai.personalwebsite.model.Article;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/articles")
public class RestArticlesController {

    private ArticleRepository articleRepository;

    @Autowired
    public RestArticlesController(ArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    @GetMapping
    public List<Article> getArticles(
            @RequestParam(value = "type", defaultValue = "-1") Integer type
            , @RequestParam(value = "size", defaultValue = "999999") Integer size) {
        if(type == -1) {
            return null;
        }
        return articleRepository.getArticles(type, size);
    }
}

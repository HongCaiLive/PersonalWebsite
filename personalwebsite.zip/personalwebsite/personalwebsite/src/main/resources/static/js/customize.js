function loadlist(type, size) {
    var types = ["the-man", "the-bachelor-of-management", "the-software-engineer", "the-artist"];

    var url;

    $.get("articles", {type: type, size: size},
        function (data) {
            for (var counter in data) {
                console.log("count : " + data[counter]);
                var li = document.createElement("li");
                li.setAttribute("class", "hex");
                var a = document.createElement("a");
                a.setAttribute("class", "hexIn");
                a.setAttribute("target", "_blank");
                var img = document.createElement("img");
                var h1 = document.createElement("h1");
                var p = document.createElement("p");

                //To be continued...
                url = "/article.html?id=" + data[counter].id;

                a.setAttribute("href", url);
                img.setAttribute("src", data[counter].image_title_url);
                p.innerHTML = data[counter].time;
                h1.innerHTML = data[counter].title;
                a.appendChild(img);
                a.appendChild(h1);
                a.appendChild(p);
                li.appendChild(a);

                $("#" + types[type - 1]).append(li);
            }
        });
}